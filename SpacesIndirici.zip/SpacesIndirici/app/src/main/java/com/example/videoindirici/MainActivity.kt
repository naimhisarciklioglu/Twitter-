package com.example.videoindirici

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val shared = intent?.takeIf { it.action == Intent.ACTION_SEND }
            ?.getStringExtra(Intent.EXTRA_TEXT).orEmpty()
        setContent { MaterialTheme { Screen(applicationContext, shared) } }
    }
}

// Paylaşılan metinden x.com / twitter.com Spaces bağlantısını ayıkla
fun extractUrl(text: String): String =
    Regex("https?://\\S+").find(text)?.value ?: text.trim()

@Composable
fun Screen(ctx: Context, initialUrl: String) {
    var url by remember { mutableStateOf(extractUrl(initialUrl)) }
    var status by remember { mutableStateOf("Hazırlanıyor…") }
    var progress by remember { mutableStateOf(0f) }
    var ready by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        withContext(Dispatchers.IO) {
            try {
                YoutubeDL.getInstance().init(ctx)
                initFfmpeg(ctx)
                runCatching { YoutubeDL.getInstance().updateYoutubeDL(ctx) }
                ready = true
                status = "Hazır. Space bağlantısını yapıştır."
            } catch (e: Exception) { status = "Başlatılamadı: ${e.message}" }
        }
    }

    Column(Modifier.fillMaxSize().padding(24.dp).statusBarsPadding(), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("Spaces İndirici", style = MaterialTheme.typography.headlineMedium)
        OutlinedTextField(
            url, { url = extractUrl(it) }, Modifier.fillMaxWidth(),
            label = { Text("x.com/i/spaces/… bağlantısı") }
        )
        Button(
            enabled = ready && !busy && url.isNotBlank(),
            onClick = {
                busy = true; progress = 0f; status = "İndiriliyor… (uzun kayıtlar birkaç dakika sürebilir)"
                scope.launch(Dispatchers.IO) {
                    try {
                        val tmp = File(ctx.cacheDir, "dl").apply { deleteRecursively(); mkdirs() }
                        val req = YoutubeDLRequest(url.trim()).apply {
                            addOption("-o", "${tmp.absolutePath}/space_%(id)s.%(ext)s")
                            addOption("-f", "bestaudio/best")
                            applyAudio(this)
                            addOption("--no-playlist")
                        }
                        YoutubeDL.getInstance().execute(req) { p, _, _ -> progress = p / 100f }
                        val f = tmp.listFiles()?.firstOrNull() ?: error("Dosya bulunamadı")
                        saveAudio(ctx, f)
                        status = "Kaydedildi: Music/SpacesKayitlari/${f.name}"
                    } catch (e: Exception) {
                        status = "Hata: ${e.message}"
                    } finally { busy = false }
                }
            }
        ) { Text("Kaydı İndir") }
        if (busy) LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth())
        Text(status)
    }
}

fun saveAudio(ctx: Context, file: File) {
    val values = ContentValues().apply {
        put(MediaStore.Audio.Media.DISPLAY_NAME, file.name)
        put(MediaStore.Audio.Media.MIME_TYPE, "audio/mp4")
        if (Build.VERSION.SDK_INT >= 29)
            put(MediaStore.Audio.Media.RELATIVE_PATH, "Music/SpacesKayitlari")
    }
    val uri = ctx.contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values)
        ?: error("Dosya yazılamadı")
    ctx.contentResolver.openOutputStream(uri)!!.use { out -> file.inputStream().use { it.copyTo(out) } }
    file.delete()
}
