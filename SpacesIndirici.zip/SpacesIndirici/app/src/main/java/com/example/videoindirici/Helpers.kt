package com.example.videoindirici

import android.content.Context
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDLRequest

fun initFfmpeg(ctx: Context) {
    FFmpeg.getInstance().init(ctx)
}

fun applyAudio(req: YoutubeDLRequest) {
    req.addOption("-x")
    req.addOption("--audio-format", "m4a")
}
